"""Independent AI-assisted demo: synthetic optical CSV validation/aggregation."""
import argparse
import csv
import json
from collections import defaultdict
from decimal import Decimal, InvalidOperation, ROUND_HALF_EVEN, localcontext
from pathlib import Path

INPUT_FIELDS = ["run_id", "sample_id", "power_mw", "beam_width_um"]
OUTPUT_FIELDS = ["run_id", "n_records", "n_power", "n_width", "missing_power",
                 "missing_width", "mean_power_mw", "mean_width_um", "status"]


class ValidationError(ValueError):
    def __init__(self, errors):
        self.errors = errors
        super().__init__("; ".join(errors))


def number(value, field):
    if value == "":
        return None
    try:
        result = Decimal(value)
    except InvalidOperation:
        raise ValueError(f"{field}: not a number") from None
    if not result.is_finite() or result < 0 or result > 1000000:
        raise ValueError(f"{field}: require finite value in [0, 1000000]")
    if field == "beam_width_um" and result == 0:
        raise ValueError("beam_width_um: require positive value when present")
    if result.as_tuple().exponent < -12:
        raise ValueError(f"{field}: at most 12 fractional decimal places")
    return result


def read_rows(path):
    rows, errors, seen = [], [], set()
    with Path(path).open(encoding="utf-8", newline="") as handle:
        reader = csv.DictReader(handle)
        if reader.fieldnames != INPUT_FIELDS:
            raise ValidationError([f"header must be exactly {INPUT_FIELDS}"])
        for line, row in enumerate(reader, 2):
            if None in row or None in row.values():
                errors.append(f"line {line}: incorrect field count")
                continue
            row = {key: value.strip() for key, value in row.items()}
            key = (row["run_id"], row["sample_id"])
            if not all(key):
                errors.append(f"line {line}: run_id and sample_id required")
                continue
            if key in seen:
                errors.append(f"line {line}: duplicate run/sample key {key}")
                continue
            seen.add(key)
            try:
                power = number(row["power_mw"], "power_mw")
                width = number(row["beam_width_um"], "beam_width_um")
            except ValueError as error:
                errors.append(f"line {line}: {error}")
                continue
            rows.append((key[0], key[1], power, width))
    if errors:
        raise ValidationError(errors)
    if not rows:
        raise ValidationError(["at least one data record required"])
    return rows


def complete_mean(values):
    if any(value is None for value in values):
        return ""
    with localcontext() as context:
        context.prec = 28
        result = sum(values, Decimal(0)) / len(values)
        rounded = result.quantize(Decimal("0.000001"), rounding=ROUND_HALF_EVEN)
    return "0.000000" if rounded == 0 else format(rounded, "f")


def aggregate(rows):
    groups = defaultdict(list)
    for run, sample, power, width in sorted(rows, key=lambda r: (r[0], r[1])):
        groups[run].append((power, width))
    results = []
    for run, measurements in sorted(groups.items()):
        powers, widths = zip(*measurements)
        count = len(measurements)
        n_power = sum(value is not None for value in powers)
        n_width = sum(value is not None for value in widths)
        results.append(dict(zip(OUTPUT_FIELDS, [
            run, count, n_power, n_width, count - n_power, count - n_width,
            complete_mean(powers), complete_mean(widths),
            "complete" if n_power == n_width == count else "missing_measurement",
        ])))
    return results


def write_results(path, rows):
    with Path(path).open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=OUTPUT_FIELDS, lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--error-report", type=Path)
    args = parser.parse_args()
    try:
        result = aggregate(read_rows(args.input))
    except (ValidationError, OSError, UnicodeError, csv.Error) as error:
        errors = error.errors if isinstance(error, ValidationError) else [str(error)]
        report = {"status": "invalid", "errors": errors, "output_written": False}
        if args.error_report:
            args.error_report.write_text(json.dumps(report, ensure_ascii=False,
                                                    indent=2) + "\n", encoding="utf-8")
        print(json.dumps(report, ensure_ascii=False))
        return 2
    write_results(args.output, result)
    print(json.dumps({"status": "ok", "runs": len(result)}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
