"""Tests for this demo's own published rules; no client test files are used."""
import csv
import tempfile
import unittest
from pathlib import Path

from aggregate import INPUT_FIELDS, ValidationError, aggregate, read_rows, write_results


class AggregationTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.path = Path(self.tmp.name) / "input.csv"

    def load(self, rows, fields=INPUT_FIELDS):
        with self.path.open("w", encoding="utf-8", newline="") as handle:
            writer = csv.writer(handle)
            writer.writerow(fields)
            writer.writerows(rows)
        return read_rows(self.path)

    def test_complete_mean_and_order(self):
        rows = self.load([["B", "2", 6, 12], ["A", "1", 0, 10], ["B", "1", 2, 8]])
        result = aggregate(rows)
        self.assertEqual([r["run_id"] for r in result], ["A", "B"])
        self.assertEqual(result[1]["mean_power_mw"], "4.000000")
        self.assertEqual(result[1]["mean_width_um"], "10.000000")

    def test_missing_is_not_zero_or_partial_mean(self):
        result = aggregate(self.load([["A", "1", 0, 10], ["A", "2", "", 20]]))[0]
        self.assertEqual(result["mean_power_mw"], "")
        self.assertEqual(result["mean_width_um"], "15.000000")
        self.assertEqual(result["missing_power"], 1)
        self.assertEqual(result["status"], "missing_measurement")

    def test_all_missing(self):
        result = aggregate(self.load([["A", "1", "", ""]]))[0]
        self.assertEqual(result["n_power"], 0)
        self.assertEqual(result["mean_width_um"], "")

    def test_zero_power_is_present(self):
        result = aggregate(self.load([["A", "1", "0", "10"]]))[0]
        self.assertEqual(result["mean_power_mw"], "0.000000")
        self.assertEqual(result["n_power"], 1)
        self.assertEqual(result["status"], "complete")

    def test_invalid_numbers_reported(self):
        for value in ["NaN", "Infinity", "-1", "oops", "1000001", "0.0000000000001"]:
            with self.subTest(value=value), self.assertRaises(ValidationError):
                self.load([["A", "1", value, 10]])

    def test_zero_width_rejected(self):
        with self.assertRaises(ValidationError):
            self.load([["A", "1", 1, 0]])

    def test_duplicate_key_rejected(self):
        with self.assertRaisesRegex(ValidationError, "duplicate"):
            self.load([["A", "1", 1, 10], ["A", "1", 2, 20]])

    def test_missing_id_and_multiple_errors(self):
        with self.assertRaises(ValidationError) as caught:
            self.load([["", "1", 1, 10], ["B", "2", "NaN", 20]])
        self.assertEqual(len(caught.exception.errors), 2)

    def test_header_and_row_shape_rejected(self):
        for fields, rows in [(["wrong"], [[1]]), (INPUT_FIELDS, [["A", "1", 1]])]:
            with self.subTest(fields=fields), self.assertRaises(ValidationError):
                self.load(rows, fields)

    def test_empty_input_rejected(self):
        with self.assertRaisesRegex(ValidationError, "at least one"):
            self.load([])

    def test_identical_output_after_row_reordering(self):
        data = [["B", "2", 6, 12], ["A", "1", 0, 10], ["B", "1", 2, 8]]
        first, second = Path(self.tmp.name) / "a.csv", Path(self.tmp.name) / "b.csv"
        write_results(first, aggregate(self.load(data)))
        write_results(second, aggregate(self.load(list(reversed(data)))))
        self.assertEqual(first.read_bytes(), second.read_bytes())


if __name__ == "__main__":
    unittest.main(verbosity=2)
