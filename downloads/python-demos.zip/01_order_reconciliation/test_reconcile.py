import unittest
from reconcile import amount, process


def row(key="O001", value="0", date="2026-08-01"):
    return dict(order_id=key, date=date, customer="架空デモ", amount_jpy=value)


class DataContractTests(unittest.TestCase):
    def test_missing_is_not_zero(self):
        p, r, _ = process([row(value="")], [dict(order_id="O001", amount_jpy="100")])
        self.assertIsNone(r[0]["incoming_jpy"])
        self.assertIsNone(r[0]["delta_jpy"])
        self.assertEqual(p[0]["status"], "要確認")

    def test_zero_is_valid(self):
        _, r, _ = process([row()], [dict(order_id="O001", amount_jpy="500")])
        self.assertEqual(r[0]["delta_jpy"], -500)
        self.assertEqual(r[0]["status"], "差異")

    def test_duplicate_and_conflict_separated(self):
        p, r, s = process([row(value="100"), row(value="100"), row(value="200")], [])
        self.assertEqual(s["duplicate_rows"], 1)
        self.assertEqual(s["review_rows"], 2)
        self.assertIsNone(r[0]["incoming_jpy"])

    def test_normalized_duplicate(self):
        _, _, s = process([row("Ｏ００１", "￥1,000"), row(" O001 ", "1000")], [])
        self.assertEqual(s["duplicate_rows"], 1)
        self.assertEqual(s["valid_amount_jpy"], 1000)

    def test_bad_grouped_number_rejected(self):
        for v in ["1,2", "1e3", "NaN", "12.5", "1,00,000"]:
            with self.subTest(v=v), self.assertRaises(ValueError):
                amount(v)

    def test_invalid_date_held(self):
        p, _, s = process([row(date="2026-02-30")], [])
        self.assertEqual(s["review_rows"], 1)

    def test_baseline_duplicate_rejected(self):
        with self.assertRaises(ValueError):
            process([row()], [dict(order_id="O001", amount_jpy="100")]*2)

    def test_join_uses_keys_not_position(self):
        _, r, s = process([row("O002", "200"), row("O001", "150")],
                            [dict(order_id="O001", amount_jpy="100"), dict(order_id="O002", amount_jpy="200")])
        self.assertEqual([x["delta_jpy"] for x in r], [50, 0])

    def test_missing_source_is_not_zero(self):
        _, r, _ = process([], [dict(order_id="O001", amount_jpy="100")])
        self.assertEqual(r[0]["status"], "取込なし")
        self.assertIsNone(r[0]["delta_jpy"])


if __name__ == "__main__":
    unittest.main(verbosity=2)
