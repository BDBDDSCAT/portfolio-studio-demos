"""AI-assisted independent demo. All bundled customer/order data is synthetic.

Python standard library only. No network access; input files are never modified.
"""
import argparse
import csv
import hashlib
import json
import re
import unicodedata
from collections import defaultdict
from datetime import datetime
from pathlib import Path


def text(value):
    return unicodedata.normalize("NFKC", value).strip()


def amount(value):
    value = text(value)
    if not value:
        raise ValueError("金額空欄")
    if value.startswith(("¥", "￥")):
        value = value[1:]
    if not re.fullmatch(r"-?(?:[0-9]+|[0-9]{1,3}(?:,[0-9]{3})+)", value):
        raise ValueError("金額形式不正")
    result = int(value.replace(",", ""))
    if abs(result) > 10**12:
        raise ValueError("金額範囲外")
    return result


def rows(path, fields):
    with Path(path).open(encoding="utf-8-sig", newline="") as f:
        reader = csv.DictReader(f)
        if reader.fieldnames != fields:
            raise ValueError("列名または列順が仕様と異なります")
        result = list(reader)
    if not result or any(None in row or None in row.values() for row in result):
        raise ValueError("データなし、または列数不正")
    return result


def process(source, baseline):
    parsed, grouped, seen = [], defaultdict(list), {}
    for line, raw in enumerate(source, 2):
        r = {"source_line": line, "order_id": text(raw["order_id"]).upper(),
             "date": "", "customer": text(raw["customer"]), "amount_jpy": None,
             "status": "有効", "reason": ""}
        errors = []
        if not re.fullmatch(r"O[0-9]{3}", r["order_id"]):
            errors.append("注文ID形式不正")
        try:
            d = text(raw["date"]).replace("/", "-")
            if not re.fullmatch(r"[0-9]{4}-[0-9]{2}-[0-9]{2}", d):
                raise ValueError()
            r["date"] = datetime.strptime(d, "%Y-%m-%d").date().isoformat()
        except ValueError:
            errors.append("日付形式不正")
        if not r["customer"]:
            errors.append("顧客名空欄")
        try:
            r["amount_jpy"] = amount(raw["amount_jpy"])
        except ValueError as e:
            errors.append(str(e))
        # Deduplicate only validated records with all normalized fields equal.
        signature = (r["order_id"], r["date"], r["customer"], r["amount_jpy"])
        if errors:
            r.update(status="要確認", reason="・".join(errors))
        elif signature in seen:
            r.update(status="重複除外", reason=f"正規化後に{seen[signature]}行目と一致")
        else:
            seen[signature] = line
        if r["status"] != "重複除外":
            grouped[r["order_id"]].append(r)
        parsed.append(r)
    for group in grouped.values():
        if len(group) > 1:
            for r in group:
                r.update(status="要確認", reason=(r["reason"] + "・" if r["reason"] else "") + "同一IDの内容不一致")
    base = {}
    for raw in baseline:
        key = text(raw["order_id"]).upper()
        if not re.fullmatch(r"O[0-9]{3}", key) or key in base:
            raise ValueError("比較元のID不正・重複。照合を中止します")
        base[key] = amount(raw["amount_jpy"])
    reconciliation = []
    for key in sorted(set(grouped) | set(base)):
        group = grouped.get(key, [])
        valid = len(group) == 1 and group[0]["status"] == "有効"
        incoming = group[0]["amount_jpy"] if valid else None
        previous = base.get(key)
        if not group:
            state, why = "取込なし", "比較元にのみ存在"
        elif not valid:
            state, why = "要確認", "・".join(dict.fromkeys(r["reason"] for r in group))
        elif key not in base:
            state, why = "新規", "比較元にIDなし"
        else:
            state, why = ("一致" if incoming == previous else "差異"), ""
        delta = incoming - previous if valid and key in base else None
        reconciliation.append({"order_id": key, "baseline_jpy": previous,
            "incoming_jpy": incoming, "delta_jpy": delta, "status": state,
            "reason": why, "source_lines": ",".join(str(r["source_line"]) for r in group)})
    summary = {
        "synthetic_data": True, "raw_rows": len(parsed),
        "valid_rows": sum(r["status"] == "有効" for r in parsed),
        "duplicate_rows": sum(r["status"] == "重複除外" for r in parsed),
        "review_rows": sum(r["status"] == "要確認" for r in parsed),
        "valid_amount_jpy": sum(r["amount_jpy"] for r in parsed if r["status"] == "有効"),
        "matched_orders": sum(r["status"] in ("一致", "差異") for r in reconciliation),
        "changed_orders": sum(r["status"] == "差異" for r in reconciliation),
        "new_orders": sum(r["status"] == "新規" for r in reconciliation),
        "review_orders": sum(r["status"] == "要確認" for r in reconciliation),
        "matched_delta_jpy": sum(r["delta_jpy"] for r in reconciliation if r["delta_jpy"] is not None),
    }
    return parsed, reconciliation, summary


def write_csv(path, data):
    with path.open("w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(data[0]), lineterminator="\n")
        writer.writeheader()
        writer.writerows(data)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("orders", type=Path)
    parser.add_argument("baseline", type=Path)
    parser.add_argument("output", type=Path, help="New output directory; existing directory is rejected")
    args = parser.parse_args()
    try:
        source = rows(args.orders, ["order_id", "date", "customer", "amount_jpy"])
        base = rows(args.baseline, ["order_id", "amount_jpy"])
        parsed, comparison, summary = process(source, base)
        args.output.mkdir(parents=True, exist_ok=False)
        write_csv(args.output / "normalized_rows.csv", parsed)
        write_csv(args.output / "reconciliation.csv", comparison)
        summary["input_sha256"] = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in (args.orders, args.baseline)}
        (args.output / "summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        print(json.dumps(summary, ensure_ascii=False))
        return 0
    except (ValueError, OSError, UnicodeError, csv.Error) as e:
        print(json.dumps({"status": "failed", "reason": str(e)}, ensure_ascii=False))
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
